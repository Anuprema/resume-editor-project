# Resume Editor – Internship Assignment

This project is a simple Resume Editor that allows users to:

- Upload a resume (mock parser)
- Edit fields like name, summary, education, experience, skills
- Enhance sections using a mock AI
- Save to backend
- Download as JSON

---

## 🔧 Tech Stack

- **Frontend:** React.js
- **Backend:** Python FastAPI

---

## 🚀 Getting Started

### Frontend

```bash
cd frontend
npm install
npm start
```

### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

---

## 📂 Project Structure

- `/frontend` – React app
- `/backend` – FastAPI backend
