import React from "react";
import axios from "axios";

function ResumeEditor({ resumeData, setResumeData }) {
  const handleChange = (e, field) => {
    setResumeData({ ...resumeData, [field]: e.target.value });
  };

  const enhanceSection = async (section) => {
    const res = await axios.post("http://localhost:8000/ai-enhance", {
      section,
      content: resumeData[section]
    });
    setResumeData({ ...resumeData, [section]: res.data.enhanced_content });
  };

  const saveResume = async () => {
    await axios.post("http://localhost:8000/save-resume", {
      resume: resumeData
    });
    alert("Resume saved!");
  };

  const downloadJSON = () => {
    const blob = new Blob([JSON.stringify(resumeData, null, 2)], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "resume.json";
    link.click();
  };

  return (
    <div>
      {Object.entries(resumeData).map(([key, value]) => (
        <div key={key}>
          <h3>{key}</h3>
          <textarea value={value} onChange={(e) => handleChange(e, key)} />
          <button onClick={() => enhanceSection(key)}>Enhance with AI</button>
        </div>
      ))}
      <button onClick={saveResume}>Save Resume</button>
      <button onClick={downloadJSON}>Download Resume</button>
    </div>
  );
}

export default ResumeEditor;
