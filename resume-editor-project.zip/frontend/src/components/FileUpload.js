import React from "react";

function FileUpload({ setResumeData }) {
  const mockParsedData = {
    name: "Jane Smith",
    summary: "Motivated software engineer...",
    experience: "Intern at XYZ",
    education: "B.Sc - IT",
    skills: "JavaScript, React"
  };

  const handleUpload = (e) => {
    e.preventDefault();
    alert("Mock upload successful.");
    setResumeData(mockParsedData);
  };

  return (
    <div>
      <input type="file" accept=".pdf,.docx" />
      <button onClick={handleUpload}>Upload Resume</button>
    </div>
  );
}

export default FileUpload;
