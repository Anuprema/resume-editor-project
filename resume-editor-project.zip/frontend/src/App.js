import React, { useState } from "react";
import FileUpload from "./components/FileUpload";
import ResumeEditor from "./components/ResumeEditor";

function App() {
  const [resumeData, setResumeData] = useState({
    name: "John Doe",
    summary: "Experienced developer...",
    experience: "Company A - 2 years",
    education: "B.Tech - CS",
    skills: "React, Python"
  });

  return (
    <div className="App">
      <h1>Resume Editor</h1>
      <FileUpload setResumeData={setResumeData} />
      <ResumeEditor resumeData={resumeData} setResumeData={setResumeData} />
    </div>
  );
}

export default App;
