from fastapi import FastAPI, Request
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class AIEnhanceRequest(BaseModel):
    section: str
    content: str

class ResumeData(BaseModel):
    resume: dict

stored_resume = {}

@app.post("/ai-enhance")
def ai_enhance(data: AIEnhanceRequest):
    enhanced = f"Enhanced version of: {data.content}"
    return {"enhanced_content": enhanced}

@app.post("/save-resume")
def save_resume(data: ResumeData):
    global stored_resume
    stored_resume = data.resume
    return {"status": "success", "message": "Resume saved."}
